AMPidentifier SVG Kit — Transparent Supplement
===============================================

Complemento ao kit principal. Todas as versões abaixo
não têm fundo (background transparente).

Nomenclatura:
  *-ink    → use sobre fundos CLAROS  (conteúdo Ink #1C1B19)
  *-paper  → use sobre fundos ESCUROS (conteúdo Paper #F1EFE8)

icons/nobg/
  icon-nobg-ink.svg            Roda helicoidal sem caixa · Ink
  icon-nobg-paper.svg          Roda helicoidal sem caixa · Paper
  icon-circle-nobg-ink.svg     Variante circular com stroke · Ink
  icon-circle-nobg-paper.svg   Variante circular com stroke · Paper

logotypes/horizontal/nobg/     680×200
logotypes/stacked/nobg/        480×380
logotypes/inline/nobg/         560×80
logotypes/wordmark/nobg/       560×120
  Cada pasta: *-ink e *-paper

logotypes/amp-display/         320×120
  Somente "AMP" — para uso hero / cover / topo de página
